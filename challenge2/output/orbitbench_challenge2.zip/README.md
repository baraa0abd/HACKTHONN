# OrbitBench — Challenge 2

**A locally maintainable CubeSat energy-design and verification tool.**

This is a separate response to the space-industry localization brief. It delivers a bounded engineering software capability: convert an assumed mission power profile into repeatable requirements checks, stress cases, and a traceable design decision.

## Deliverables

- [Engineering dossier](docs/01_ENGINEERING_DOSSIER.md): scope, requirements, architecture, physics, results, and limitations.
- [Localization and TRL plan](docs/02_LOCALIZATION_AND_TRL.md): local development boundary, supply chain, laboratory validation, and commercialization milestones.
- [Execution and pitch](docs/03_EXECUTION_AND_PITCH.md): roles, schedule, live demonstration, and judge questions.
- [Offline evidence report](output/orbitbench.html): initial/candidate comparison, battery traces, stress cases, and test results.
- Full Python source, example configuration, automated tests, CSV search results, and run hashes.

## Run

Python 3.10 or newer; standard library only. No installation, API key, GPU, or cloud service is needed.

```shell
python run.py
```

On this Windows workspace:

```powershell
.\run_demo.ps1
```

Evaluate a different assumed mission:

```shell
python run.py --config examples/mission.json --output output/custom
```

Evaluate one design without running the search:

```shell
python orbit.py examples/mission.json --output output/single_result.json
```

Outputs are regenerated. Keep any manually annotated reports in a different directory. A null `candidate_config.json` means that no candidate passed; it is not a runnable design configuration.

## Verified demonstration

| Item | Result |
|---|---|
| Automated tests | 8 passed |
| Search | 101 duty values × 8 stress corners = 808 simulations |
| Initial design | 65% payload duty; nominal energy deficit; battery reaches zero |
| Best passing grid candidate | 19% duty under the specified model and eight corners |
| Worst candidate surplus | Approximately 0.034 Wh/orbit: very little remaining margin |
| Example lower-duty alternative | At 15% duty, worst modeled surplus is approximately 0.409 Wh/orbit |

The search maximizes duty on its specified grid. It does not demonstrate that a 19% duty cycle meets the mission's science objective, electrical peak loads, or flight constraints. If 65% is a non-negotiable mission requirement, this is an **infeasible architecture**, not a repaired mission: change power generation, loads, or mission requirements and rerun.

## Evidence boundary

The software and test evidence are real. All mission parameters are assumptions; no bench or flight telemetry is included. Provisional maturity is a TRL 2 concept progressing toward a candidate TRL 3 software proof of concept, subject to independent review. No hardware or spacecraft TRL is established.

The local capability is source ownership/control, engineering workflow, repeatable analysis, and future instrument integration. No existing supplier relationship, certified laboratory access, completed local manufacture, or measured import-cost reduction is claimed.
